module.exports = require('./config/profiles.cjs').jestProfile('overall', 'baseline', true);
