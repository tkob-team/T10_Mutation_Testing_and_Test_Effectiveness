# Research Test Environment

## Scope and Provenance

Repo này giữ SUT EShop và test harness của seminar. Production code cố ý có lỗi theo đặc tả trong README và API specification. Không sửa production để làm tests pass hoặc tăng mutation score.

Production reference là commit `806ba19ee4e09eafe9b2696ccf117a2b1ab841ef`. Revision nhận audit là `4b28756a1d2a59cb4b74300709122180056f9f55`; server.js, database.js và tracked database có cùng Git blobs với reference. Các sửa harness/config sau đó tạo conditions mới, không thay kết quả lịch sử.

Cart manual và AI được nhập nguyên bytes từ `b77f5d6ab580ae1823fb4272290116a94328c42e` và `f4696c6188d2277fe860a7f7ad2fe2234f61b68c`. Xem [input manifest](backend/experiments/inputs.json). Giữ attribution trong source; agent không nhận đây là assertions mới tự sinh. Coupons manual và AI từng có Codex hỗ trợ trong cùng context. Các collections có số scenarios và nguồn oracle khác nhau, không chứng minh human-versus-AI hoặc model ranking.

## Install

Môi trường tham chiếu: Windows x64, Node.js 24.16.0, npm 12.0.2. `.nvmrc` chọn Node tham chiếu; backend engines chọn nhánh Node 24 tương thích với dependency graph. Chạy trong backend:

```powershell
node --version
npm --version
npm ci
npm test
```

SQLite có native install script đã khai báo trong allowScripts. Nếu bindings không nạp được, kiểm tra log cài đặt và phiên bản npm trước khi chạy lại. Không xóa lockfile hoặc bật toàn bộ scripts để bỏ qua lỗi. setup_guide.md đã được đồng bộ yêu cầu Node vì mức từ 18 trong hướng dẫn cũ không đủ cho research toolchain này.

## Profiles and Commands

| Domain | Baseline cases | Manual collection cases | AI collection cases |
|---|---:|---:|---:|
| cart-orders | 36 | 44 | 41 |
| coupons | 26 | 35 | 40 |
| auth | 26 | 39 | 37 |
| overall | 88 | 118 | 118 |

Đây là expected unique Jest cases để đối chiếu với report, không tự xác nhận đã pass. Mỗi collection gồm baseline của domain và đúng phần bổ sung tương ứng. Passing baseline không chứa known-defect tests.

```powershell
npm run test:cart-orders
npm run test:cart-orders:manual
npm run test:cart-orders:ai
npm run test:coupons:manual
npm run test:auth:ai
npm run test:manual
npm run test:ai
npm run dry:overall
npm run mutate:overall
npm run mutate:overall:manual
npm run mutate:overall:ai
```

Mọi domain có scripts `test:<domain>`, `dry:<domain>`, `mutate:<domain>` và suffix `:manual` hoặc `:ai`. Cấu hình chung ở backend/config/profiles.cjs. JSON mutation configs là file được lưu để mở trực tiếp bằng Stryker; phải giữ khớp factory. Report paths tách theo domain và collection.

Single-domain Jest configs không kế thừa multi-project selection. Overall có hai Jest projects vì Auth dùng database mock riêng, còn Cart và Coupons dùng production schema với SQLite trong bộ nhớ. Mutation projects dùng Stryker-aware Node environment để ghi per-test coverage. Shared cleanup đóng DB, khôi phục clock và spies trong từng test environment.

Policy mutation mới: perTest, concurrency 1, timeoutMS 5000, timeoutFactor 1.5. Lịch sử dùng concurrency 2 và có selection khác. Không xem số đo mới là reproduction bit-for-bit của conditions cũ.

## Original Defects and Oracles

```powershell
npm run test:defects
```

Profile này được kỳ vọng fail tại assertions trên production gốc. Có 54 cases lịch sử, gồm Cart 9, Coupons 22 và Auth 23. Setup exceptions, native crashes và hook failures là lỗi thực thi cần điều tra, không phải bằng chứng defect assertion hợp lệ.

Mutant sửa đúng một original defect không tự trở thành equivalent mutant hoặc bằng chứng test yếu. Đối chiếu spec và scope trước khi diễn giải survivor đó.

Cart baseline chủ yếu kiểm tra status theo thiết kế lịch sử. Không tự đổi assertions trong baseline rồi dùng report cũ làm đối chứng. Một số Cart manual expected messages/order và Auth error codes là implementation observations hoặc conventions. Auth AI lock-expiry equality là interpretation. OTP phải hết hạn theo spec nhưng 24 giờ trong DF-10 không phải TTL được spec quy định. Coupon quote, checkout và usage recording là ba API calls riêng, không chứng minh atomic transaction hoặc tự ghi usage.

## Complete Audit

Dùng hai đường dẫn tuyệt đối mới. Runtime nằm ngoài source và evidence. Runner copy inputs, cài từ lockfile, kiểm tra discovery và unique case counts cho 12 profiles, chạy shuffled baseline, known defects, tutorials, dry runs và mutation, rồi build web/admin. Không cần mở UI hoặc server cho API tests.

```powershell
cd backend
npm run audit -- D:\Temp\t10-audit-evidence D:\Temp\t10-audit-runtime
node scripts/summarize-audit.cjs D:\Temp\t10-audit-evidence
```

Runner lưu source snapshots, hashes, commands, logs, standalone Jest JSON và HTML/JSON mutation reports. Không ghi đè lần chạy cũ. `--resume` chỉ dùng khi tiếp tục cùng inputs và các commands trước đã đạt exit code kỳ vọng. Sau khi sửa code do failure, dùng output/runtime mới để giữ evidence thất bại. `--tests-only` kiểm chứng tests trước khi full mutation; `--backend-only` bỏ frontend builds khi có phạm vi riêng được ghi rõ.

Runtime và tracked database được kiểm hashes trước/sau. Evidence thuộc Agent execution; human review và member self-runs cần record riêng. Frontend builds không chứng minh browser behavior; mobile/device execution cần môi trường riêng và không được runner nhận là đã chạy.

## Results and Interpretation

Giữ Killed, Timeout, Survived, NoCoverage và RuntimeError riêng. Stryker tool score tính cả Timeout trong detected và loại RuntimeError/CompileError khỏi valid. Added assertion kills chỉ đếm transitions từ Survived/NoCoverage sang Killed với matched signatures; xem failing assertion trước khi diễn giải những mutants trọng yếu. So sánh chung cần overall runs thật, không cộng hoặc trung bình domain scores.

## Sources

- [Jest configuration](https://jestjs.io/docs/configuration)
- [Stryker Jest runner](https://stryker-mutator.io/docs/stryker-js/jest-runner/)
- [Stryker configuration](https://stryker-mutator.io/docs/stryker-js/configuration/)
- [Mutant states and metrics](https://stryker-mutator.io/docs/mutation-testing-elements/mutant-states-and-metrics/)
- [npm ci](https://docs.npmjs.com/cli/v12/commands/npm-ci)
