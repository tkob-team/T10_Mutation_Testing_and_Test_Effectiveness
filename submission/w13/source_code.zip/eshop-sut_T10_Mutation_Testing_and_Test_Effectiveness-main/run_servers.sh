#!/usr/bin/env bash
set -euo pipefail
repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
pids=()
cleanup() {
  for child in "${pids[@]}"; do kill "$child" 2>/dev/null || true; done
}
trap cleanup EXIT
trap 'exit 130' INT TERM
echo "The backend reseeds backend/database.sqlite on startup. Use an isolated copy for demos."
(cd "$repo_dir/backend" && exec node server.js) &
pids+=("$!")
(cd "$repo_dir/frontend-web" && exec npm run dev) &
pids+=("$!")
(cd "$repo_dir/frontend-admin" && exec npm run dev) &
pids+=("$!")
wait
